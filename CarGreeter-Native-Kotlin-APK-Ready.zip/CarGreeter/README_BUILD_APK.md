# Car Greeter — native Kotlin APK

This project is prepared as a native Android application. It supports:
- Text-to-Speech Vietnamese greeting.
- Trigger after unlock.
- Trigger when power/charging is connected.
- Trigger when a Bluetooth device connects (permission required on Android 12+).
- Optional full-screen image notification/activity.
- Foreground service and restart after device boot.

## Build APK
Open the project in Android Studio and use **Build > Build APK(s)**.

For a cloud build without Android Studio, push this folder to a GitHub repository. The included workflow `.github/workflows/build-apk.yml` builds `app-debug.apk` and uploads it as a workflow artifact.

## Android limitations
Android controls background execution and full-screen intents. The user must grant notification/Bluetooth permissions where requested. Some Android versions/OEMs may restrict automatic startup or background behavior with battery optimization; disable battery optimization for Car Greeter if the device manufacturer suppresses background services.
