package com.example.cargreeter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Màn hình cấu hình macro: đổi câu chào, chọn nhiều điều kiện kích hoạt,
 * chọn ảnh hiển thị, và bật/tắt dịch vụ chạy nền - tương đương bản mô
 * phỏng web nhưng chạy thật trên thiết bị.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var edtPhrase: EditText
    private lateinit var chkUnlock: CheckBox
    private lateinit var chkCharge: CheckBox
    private lateinit var chkBluetooth: CheckBox
    private lateinit var imgPreview: ImageView
    private lateinit var txtStatus: TextView
    private lateinit var btnToggle: Button

    private var pickedImageUri: Uri? = null

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                pickedImageUri = uri
                imgPreview.setImageURI(uri)
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val bluetoothPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtPhrase = findViewById(R.id.edtPhrase)
        chkUnlock = findViewById(R.id.chkUnlock)
        chkCharge = findViewById(R.id.chkCharge)
        chkBluetooth = findViewById(R.id.chkBluetooth)
        imgPreview = findViewById(R.id.imgPreview)
        txtStatus = findViewById(R.id.txtStatus)
        btnToggle = findViewById(R.id.btnToggle)
        val btnPickImage = findViewById<Button>(R.id.btnPickImage)
        val btnSave = findViewById<Button>(R.id.btnSave)

        loadFromPrefs()
        requestRuntimePermissionsIfNeeded()

        btnPickImage.setOnClickListener {
            pickImageLauncher.launch(arrayOf("image/*"))
        }

        btnSave.setOnClickListener {
            saveToPrefs()
            Toast.makeText(this, "Đã lưu cấu hình", Toast.LENGTH_SHORT).show()
        }

        btnToggle.setOnClickListener {
            saveToPrefs()
            val enabled = !Prefs.isServiceEnabled(this)
            Prefs.setServiceEnabled(this, enabled)
            if (enabled) startGreeterService() else stopGreeterService()
            updateStatusUi()
        }

        updateStatusUi()
    }

    private fun loadFromPrefs() {
        edtPhrase.setText(Prefs.getPhrase(this))
        chkUnlock.isChecked = Prefs.isUnlockTriggerEnabled(this)
        chkCharge.isChecked = Prefs.isChargeTriggerEnabled(this)
        chkBluetooth.isChecked = Prefs.isBluetoothTriggerEnabled(this)

        Prefs.getImageUri(this)?.let { uriString ->
            runCatching {
                val uri = Uri.parse(uriString)
                pickedImageUri = uri
                imgPreview.setImageURI(uri)
            }
        }
    }

    private fun saveToPrefs() {
        Prefs.setPhrase(this, edtPhrase.text.toString().ifBlank {
            "Chào sếp, hệ thống xe đã sẵn sàng khởi hành."
        })
        Prefs.setTriggers(
            this,
            unlock = chkUnlock.isChecked,
            charge = chkCharge.isChecked,
            bluetooth = chkBluetooth.isChecked
        )
        Prefs.setImageUri(this, pickedImageUri?.toString())
    }

    private fun startGreeterService() {
        val intent = Intent(this, GreetingForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopGreeterService() {
        stopService(Intent(this, GreetingForegroundService::class.java))
    }

    private fun updateStatusUi() {
        val running = Prefs.isServiceEnabled(this)
        txtStatus.text = if (running) "Đang chạy ngầm" else "Đang tắt"
        btnToggle.text = if (running) "Tắt Macro" else "Bật Macro"
    }

    private fun requestRuntimePermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                bluetoothPermissionLauncher.launch(
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                )
            }
        }
    }
}
